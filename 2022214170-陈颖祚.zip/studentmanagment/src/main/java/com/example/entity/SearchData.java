package com.example.entity;

public class SearchData {
    public String name;
    public String stuNumber;
    public Major major;
    public School school;
    public String stuType;
}
